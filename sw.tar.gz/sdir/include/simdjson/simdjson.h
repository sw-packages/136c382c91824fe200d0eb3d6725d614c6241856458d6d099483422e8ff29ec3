/**
 * @file
 * @deprecated We will be removing this file so it is not confused with the top level simdjson.h
 */
#ifndef SIMDJSON_SIMDJSON_H
#define SIMDJSON_SIMDJSON_H

#include "simdjson/compiler_check.h"
#include "simdjson/error.h"

#endif // SIMDJSON_SIMDJSON_H
